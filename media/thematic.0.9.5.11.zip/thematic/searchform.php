<?php
		thematic_search_form()
?>
